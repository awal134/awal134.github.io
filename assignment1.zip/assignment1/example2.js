
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255);
  circle(130,225,150);
  fill(255,0,0,75);
  circle(180,150,150);
  fill(0,255,0,75)
  circle(230,225,150);
  fill(0,0,255,75)
}
