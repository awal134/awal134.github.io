function setup() {
  createCanvas(400, 200);
}

function draw() {
  background(157,255,20);
  circle(100,100,160);
  square(210,25,150)
}
